%% Benjamin Wong
% Monash University
% April 2020

clear all
clc

addpath('_func')

% Test script to estimate Australia BVAR of employment growth
% Read data, 19 sectors in the first 19 columns - total in the 20th column
alldata = xlsread("ABSemploymentOriginal.xlsx", "B12:U153");
% Transform data to year on year growth rate 100*ln(y_t/y_{t-4})
logdat = log(alldata);
% Change later if we are doing BVAR on all sectors
y = 100*(logdat(5:end,1:20)-logdat(1:(end-4),1:20));

N = size(y,2);
p = 4;
lambda = 0.2; %shrinakge
maxhor = 2; %maximum forecast horizon where we are imposing conditions

[phi,SIGMA,X,e] = BVAR(y,p,lambda);
A0 = chol(SIGMA,'lower');

[unconditional_forecasts] = unconditional_forecast(phi,y(end:-1:end-p+1,:),20);

%% Conditional Forecast
%
specify_conditions = NaN(maxhor,N);
specify_conditions(1,20) = -10;

[uncond_forecast_max_hor] = unconditional_forecast(phi,y(end:-1:end-p+1,:),maxhor);
gap = specify_conditions-uncond_forecast_max_hor; %gap between conditional and unconditional forecast

[IRF] = calculate_IRF_FEVD(phi,A0,maxhor-1);

%construct M matrix and B vector. B is the vector of reduced form forecast
%errors. M stacks the IRF to multiply by the structural shocks to give the
%conditions B

q = 0; %number of restrictions

B = [];
M = zeros(q,maxhor*N);

for jj = 1:size(specify_conditions,1) %loop over horizon
    for ii = 1:size(specify_conditions,2)
        if isnan(specify_conditions(jj,ii)) == 0
            q = q+1; %keep track on constraints
           
            B(q,1) = gap(jj,ii);
            M(q,1:N*jj) = (reshape(fliplr(IRF(ii:N:end,1:jj)),[],1))';            
        end
    end
end

% Solving out structural shocks
fun = @(epsilon) epsilon'*epsilon;
epsilon0 = randn(maxhor*N,1);

Aeq = M;
beq = B;
epsilon = fmincon(fun,epsilon0,[],[],Aeq,beq);


%solve for reduced form shocks
for jj = 1:maxhor
    ehat(jj,:) = (A0*epsilon((jj-1)*N+1:jj*N))'; 
end


[conditional_forecasts] = conditional_forecast(phi,y(end:-1:end-p+1,:),ehat,20);

